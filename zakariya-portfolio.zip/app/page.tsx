
"use client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Portfolio() {
  return (
    <main className="p-6 max-w-4xl mx-auto space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Zakariya Mustafe</h1>
        <p className="text-xl text-gray-600">
          Graduate Software Engineer & IT Support Specialist
        </p>
        <p>
          Passionate about building modern, scalable applications and solving real-world tech challenges.
        </p>
        <Button asChild>
          <a href="mailto:zakmohamed59@gmail.com">Get in Touch</a>
        </Button>
      </section>

      {/* Experience Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Experience</h2>
        <Card className="mb-4">
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold">Freelancer | Software Engineer</h3>
            <p className="text-sm text-gray-500">London | Apr 2024 – Present</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Developed full-stack apps with React.js, Tailwind, TypeScript, and PHP</li>
              <li>Utilized AWS and Terraform for cloud-based deployments</li>
              <li>Built API integrations with Golang</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold">Global Net | IT Support Analyst</h3>
            <p className="text-sm text-gray-500">London | Jan 2023 – Jan 2024</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Provided support for Windows, macOS, and Linux systems</li>
              <li>Used Active Directory, Office 365, SCCM, and Exchange</li>
              <li>Handled network and hardware troubleshooting (printers, laptops, routers)</li>
              <li>Managed ServiceNow tickets and remote support via TeamViewer/VNC</li>
            </ul>
          </CardContent>
        </Card>
      </section>

      {/* Skills Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Skills</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            "React.js", "Tailwind CSS", "JavaScript", "Python", "PHP", "SQL", "Git",
            "HTML5", "CSS3", "AWS", "Azure", "Office 365", "Exchange 2010–2016",
            "Sophos", "McAfee", "Norton", "Backup Exec", "Active Directory",
            "Windows Server 2012/2016/2019", "Cisco Routers & Switches",
            "SCCM", "TeamViewer", "VNC", "Mac Devices", "Dell/HP/Toshiba laptops"
          ].map(skill => (
            <div key={skill} className="bg-gray-100 rounded-xl p-2 text-center text-sm">
              {skill}
            </div>
          ))}
        </div>
      </section>

      {/* Education */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Education</h2>
        <Card>
          <CardContent className="p-4">
            <h3 className="text-xl font-semibold">Goldsmiths, University of London</h3>
            <p className="text-sm text-gray-500">BSc Business Computing (Entrepreneurship) | Sept 2019 – Jan 2023</p>
            <p>Graduated with 2:1. Final project: built a business-oriented web app.</p>
          </CardContent>
        </Card>
      </section>

      {/* Contact */}
      <section className="text-center">
        <h2 className="text-2xl font-semibold mb-4">Let’s Connect</h2>
        <p className="mb-2">Email: <a href="mailto:zakmohamed59@gmail.com" className="text-blue-600">zakmohamed59@gmail.com</a></p>
        <p>GitHub: <a href="https://github.com/za205" target="_blank" className="text-blue-600">github.com/za205</a></p>
      </section>
    </main>
  );
}
